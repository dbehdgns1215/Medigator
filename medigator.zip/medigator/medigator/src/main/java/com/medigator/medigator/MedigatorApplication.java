package com.medigator.medigator;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MedigatorApplication {

	public static void main(String[] args) {
		SpringApplication.run(MedigatorApplication.class, args);
	}

}
