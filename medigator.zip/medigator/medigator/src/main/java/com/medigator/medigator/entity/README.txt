Entity (엔티티):

데이터베이스의 테이블과 매핑되는 객체입니다.
엔티티는 데이터베이스의 레코드를 표현하며, 데이터베이스에서 조회, 저장, 수정, 삭제 등의 CRUD(Create, Read, Update, Delete) 작업을 수행합니다.
보통 JPA(Java Persistence API)를 사용하여 엔티티를 정의하고 데이터베이스와의 상호작용을 구현합니다.